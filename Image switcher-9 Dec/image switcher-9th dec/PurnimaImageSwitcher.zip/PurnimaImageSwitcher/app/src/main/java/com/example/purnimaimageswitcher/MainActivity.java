package com.example.purnimaimageswitcher;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
Button b1;
ImageView iv;
boolean flag;
int images[]={R.drawable.img1,R.drawable.img2,R.drawable.img3};
int i=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iv=(ImageView) findViewById(R.id.img1);
        b1=(Button) findViewById(R.id.button);

        flag=true;
        iv.setImageResource(images[0]);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                iv.setImageResource(images[i]);
                i++;
                if(i==3) i=0;
            }
        });
    }
}